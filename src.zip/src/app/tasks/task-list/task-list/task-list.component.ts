import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../../core/services/task.service';
import { Task } from '../../../core/models/task.model';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-task-list',
  standalone: false,
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
  tasks: Task[] = [];
  editTask:Task|null=null;

  isAdmin:boolean=false;

  // priorityOptions = [{name:"Low", value:"Low"},
  //   {name:"Normal", value:'Normal'},
  //   {name:"High", value:"High"}];
  
  constructor(private _task: TaskService, private _auth:AuthService) {
    this.isAdmin = this._auth.isAdmin(); 
  }

  ngOnInit(): void {
    this._task.$task.subscribe(tasks => this.tasks = tasks);
  }

  deleteTask(id: number): void {
    this._task.removeTask(id);
  }

  edit(task:Task){
    this.editTask={...task}
  }

  UpdateTask():void{
    if(this.editTask){
      this._task.updateTask(this.editTask);
      this.editTask=null
    }
  }

  updateTaskStatus(id: number, newStatus: 'Pending' | 'In Progress' | 'Completed'): void {
    this._task.updateTaskStatus(id, newStatus);
  }
}
