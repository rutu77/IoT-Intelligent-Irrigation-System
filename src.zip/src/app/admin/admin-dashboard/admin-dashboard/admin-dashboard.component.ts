import { Component, OnInit } from '@angular/core';
import { User } from '../../../core/models/user.model';
import { UserService } from '../../../core/services/user.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: false,
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit{
  users:User[]=[]

  newUser:User={id:0,name:"",password:"",role:'user'}

  editUser:User|null= null

  constructor(private _user:UserService){}

  ngOnInit(): void {
    this._user.$user.subscribe(users=>this.users=users)
  }

  addUser():void{
    this.newUser.id=Date.now();
    this._user.addUser(this.newUser)
    this.newUser={id:0,name:"",password:"",role:'user'}
  }

  deleteUser(id:number):void{
    this._user.removeUser(id)
  }

  edit(user:User){
    this.editUser={...user}
  }

  updateUsers():void{
    if(this.editUser){
      this._user.updateUser(this.editUser);
      this.editUser=null
  }
}

}