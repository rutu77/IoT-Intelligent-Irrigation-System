import { Component } from '@angular/core';
import { AuthService } from '../../../core/services/auth.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  standalone: false,
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  username: string = '';
  password: string = '';
  role: 'user' | 'admin' = 'user';
  errorMsg: string = '';

  constructor(private _auth: AuthService, private router: Router) {}

  form= new FormGroup({
    username:new FormControl('',[Validators.required, Validators.minLength(3)]),
    password:new FormControl('',[Validators.required,Validators.minLength(8)]),
    role:new FormControl(this.role,[Validators.required])
  })

  

  register() {
    const {username,password,role}=this.form.value;
    this.username=username!;
    this.password=password!;
    this.role=role!;

    if (this._auth.register(username!, password!, role!)) {
      alert('Registration successful! Redirecting to login...');
      this.router.navigate(['/login']);
    } else {
      this.errorMsg = 'User already exists! Please log in.';
      this.router.navigate(['/auth/login']);
    }
  }

  // register() {
  //   if (this._auth.register(this.username, this.password, this.role)) {
  //     alert('Registration successful! Redirecting to login...');
  //     this.router.navigate(['/login']);
  //   } else {
  //     this.errorMsg = 'User already exists! Please log in.';
  //     this.router.navigate(['/auth/login']);
  //   }
  // }
}

